## 申请开通Paypal
* [登录/注册](https://www.paypal.com/c2/signin)
* 打开[paypal开发者中心](https://developer.paypal.com/developer/applications)
选择 **Apps & Credentials** 点击 **Create App**创建应用，创建后点击编辑按钮，如图：
![](https://native-res.dcloud.net.cn/images/uniapp/payment/paypal_app_center.png)
* 进入应用详情，勾选**Log in with PayPal**点击 **Advanced Settings** 添加return URL等信息并保存。如图：
![](https://native-res.dcloud.net.cn/images/uniapp/payment/paypal_add_feature.png)

![](https://native-res.dcloud.net.cn/images/uniapp/payment/paypal_edit_logininfo.png)


