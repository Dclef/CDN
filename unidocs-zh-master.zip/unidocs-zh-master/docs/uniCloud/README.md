`请前往新地址访问`：文档地址已迁移至：[https://doc.dcloud.net.cn/uniCloud/](https://doc.dcloud.net.cn/uniCloud/)

`请前往新仓库修改`：文档仓库已迁移至 [https://gitcode.net/dcloud/unidocs-unicloud-zh](https://gitcode.net/dcloud/unidocs-unicloud-zh)