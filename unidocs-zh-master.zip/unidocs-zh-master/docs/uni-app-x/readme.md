`请前往新地址访问`：文档地址已迁移至：[https://doc.dcloud.net.cn/uni-app-x/](https://doc.dcloud.net.cn/uni-app-x/)

`请前往新仓库修改`：文档仓库已迁移至 [https://gitcode.net/dcloud/unidocs-uni-app-x-zh](https://gitcode.net/dcloud/unidocs-uni-app-x-zh)