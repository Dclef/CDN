## 申请开通Stripe
* [登录/注册](https://dashboard.stripe.com/login)

* 进入主页后，点击顶部继续按钮
![](https://native-res.dcloud.net.cn/images/uniapp/payment/stripe_home_page.png)

* 完善公司信息
![](https://native-res.dcloud.net.cn/images/uniapp/payment/stripe_company_info.png)

* 完善信息后，回到首页即可在右侧查看密钥
![](https://native-res.dcloud.net.cn/images/uniapp/payment/stripe_get_publishkey.png)

