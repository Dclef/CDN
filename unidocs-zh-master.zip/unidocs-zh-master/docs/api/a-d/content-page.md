### 短视频内容联盟广告

简介

⼀个视频内容频道，支持上下滑动切换视频内容

![](https://qiniu-web-assets.dcloud.net.cn/unidoc/zh/ad-content-page.png)


内容联盟广告是一个原生全屏组件，大小不可控制

如果需要嵌入到页面控制大小请使用 [短视频内容联盟组件<ad-content-page />](https://uniapp.dcloud.net.cn/component/ad-content-page)

**平台差异说明**

|App|H5|微信小程序|支付宝小程序|百度小程序|抖音小程序、飞书小程序|QQ小程序|快手小程序|京东小程序|
|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
|√（3.1.5+）|x|x|x|x|x|x|x|x|


**开通配置广告**

[开通广告步骤详情](https://uniapp.dcloud.net.cn/uni-ad.html#start)


文档已迁移至 [短视频内容联盟广告](https://uniapp.dcloud.net.cn/uni-ad/ad-content-page.html)
