
#### 卡券

仅微信小程序、支付宝小程序支持，各平台开发方式暂未统一，使用时需注意用[条件编译](https://uniapp.dcloud.io/platform)调用不同平台的代码。

- 微信小程序：[规范详情](https://developers.weixin.qq.com/miniprogram/dev/api/wx.openCard.html)
- 支付宝小程序：[规范详情](https://docs.alipay.com/mini/api/card-voucher-ticket)