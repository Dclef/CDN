
`uni-app`可以多端输出，也欢迎各平台之前的老项目向uni-app转换迁移。


**vue h5项目转换uni-app指南：**[https://ask.dcloud.net.cn/article/36174](https://ask.dcloud.net.cn/article/36174)

**微信小程序转换uni-app指南及转换器：**[https://ask.dcloud.net.cn/article/35786](https://ask.dcloud.net.cn/article/35786)

**wepy转uni-app转换器：**[https://github.com/zhangdaren/wepy-to-uniapp](https://github.com/zhangdaren/wepy-to-uniapp)

**另一种有效的wepy转uni-app方法：** [https://ask.dcloud.net.cn/article/39125](https://ask.dcloud.net.cn/article/39125)

**mpvue 项目（组件）迁移指南、示例及资源汇总：** [https://ask.dcloud.net.cn/article/34945](https://ask.dcloud.net.cn/article/34945)
