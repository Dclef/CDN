export const LOCALE_ZH_HANS = 'zh-CN'
export const LOCALE_EN = 'en-US'