## android内置依赖

|依赖名|
|------|
|com.alibaba:fastjson:1.1.46.android|
|androidx.core:core-ktx:1.6.0|
|org.jetbrains.kotlin:kotlin-gradle-plugin:1.5.10|
|org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.6.0|
|org.jetbrains.kotlin:kotlin-reflect:1.6.0|
|org.jetbrains.kotlinx:kotlinx-coroutines-core:1.3.8|
|org.jetbrains.kotlinx:kotlinx-coroutines-android:1.3.8|



