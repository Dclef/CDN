
### uni.createOffscreenCanvas()

创建离屏 canvas 实例

仅微信小程序平台支持，[规范详情](https://developers.weixin.qq.com/miniprogram/dev/api/wx.createOffscreenCanvas.html)
