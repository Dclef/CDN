// 此处需要使用 commonjs

module.exports = {
  copyText: '复制代码',
  tip: { content: "复制成功", title: "" },
  visibleTip: true,
}