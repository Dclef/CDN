### 应用生命周期

``uni-app`` 支持 onLaunch、onShow、onHide 等应用生命周期函数，详情请参考[应用生命周期](/collocation/App.md#applifecycle)

### 页面生命周期

``uni-app`` 支持 onLoad、onShow、onReady 等生命周期函数，详情请参考[页面生命周期](/tutorial/page.md#lifecycle)