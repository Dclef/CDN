## uni-push

UniPush 是 DCloud 联合个推公司推出的集成型统一推送服务，是所有uni-app开发者首选的推送服务。

有两个版本：
- 2.0版新版文档地址：[https://uniapp.dcloud.net.cn/unipush-v2.html](https://uniapp.dcloud.net.cn/unipush-v2.html)
- 1.0版老版文档地址：[https://uniapp.dcloud.net.cn/unipush-v1.html](https://uniapp.dcloud.net.cn/unipush-v1.html)