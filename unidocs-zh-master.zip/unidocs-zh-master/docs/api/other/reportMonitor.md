
#### uni.reportMonitor()

自定义业务数据监控上报接口。

微信小程序平台[规范详情](https://developers.weixin.qq.com/miniprogram/dev/api/wx.reportMonitor.html)
QQ小程序平台[规范详情](https://q.qq.com/wiki/develop/miniprogram/API/open_port/port_dataup.html#qq-reportmonitor)
