# 运行自定义基座到iOS模拟器

HBuilderX 3.7.13起，MacOSX系统，App项目，支持运行自定义基座到iOS模拟器。

### 制作iOS模拟器自定义基座

MacOSX系统，App项目，运行自定义基座到iOS模拟器前，需要先制作自定义基座。

如何制作自定义基座？ 选择项目，点击顶部菜单【发行】【原生App - 云打包】，如下窗口所示：

<img src="http://qiniu-web-assets.dcloud.net.cn/unidoc/zh/app-pack-make-ios-simulator-custom-base.jpg" style="zoom: 50%;"/>

### iOS模拟器设备选择窗口选择自定义基座

选择uni-app等App项目，点击工具栏运行菜单，在下拉列表中，点击【运行到iOS模拟器 App基座】

<img src="http://qiniu-web-assets.dcloud.net.cn/unidoc/zh/run-custom-base-ios-simulator.jpg" style="zoom: 50%;"/>