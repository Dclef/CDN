# uniMP激励视频广告

## 简介

通过App打开微信小程序播放激励视频广告

为了给开发者提供更高价格的广告，uni-ad 推出了高阶游戏广告预算。目前这种广告主预算只支持激励视频广告位

利用 uni-ad 多层调度策略动态调整渠道，在设备无广告时自动调整为其他广告渠道以增加广告填充率

<video controls src="https://qiniu-web-assets.dcloud.net.cn/unidoc/zh/uni-ad/ad-unimp.x264.mp4" style="max-width: 100%; max-height: 50vh;"></video>

文档已迁移至 [uniMP激励视频广告](https://uniapp.dcloud.net.cn/uni-ad/unimp.html)
