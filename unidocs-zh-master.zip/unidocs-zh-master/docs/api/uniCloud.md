### uniCloud

完整uniCloud客户端api列表请参考：[uniCloud客户端sdk](https://doc.dcloud.net.cn/uniCloud/client-sdk.html)



