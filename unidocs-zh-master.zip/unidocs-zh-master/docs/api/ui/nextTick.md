###  nextTick(function callback)
在小程序自定义组件，如wxcomponents中使用。延迟一部分操作到下一个时间片再执行。（类似于 setTimeout） 。其他平台无此概念。

- 微信小程序：[规范详情](https://developers.weixin.qq.com/miniprogram/dev/api/wx.nextTick.html)
- 百度小程序：[规范详情](https://smartprogram.baidu.com/docs/develop/api/custom_component/#swan-nextTick/)
- QQ小程序：[规范详情](https://q.qq.com/wiki/develop/miniprogram/API/interface/interface_nexttick.html#qq-nexttick)
