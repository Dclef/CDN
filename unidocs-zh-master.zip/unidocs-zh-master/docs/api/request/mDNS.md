
#### mDNS 服务

 - 微信小程序平台支持，[规范详情](https://developers.weixin.qq.com/miniprogram/dev/api/wx.stopLocalServiceDiscovery.html)
 - App端可在插件市场搜索相关插件[mDNS](https://ext.dcloud.net.cn/search?q=mdns)
