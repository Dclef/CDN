#### official-account

微信公众号关注组件。当用户扫小程序码打开小程序时，开发者可在小程序内配置公众号关注组件，方便用户快捷关注公众号，可嵌套在原生组件内。

仅微信小程序平台支持，[规范详情](https://developers.weixin.qq.com/miniprogram/dev/component/official-account.html)

支付宝平台另提供了`lifestyle`组件，可关注支付宝生活号，[规范详情](https://docs.alipay.com/mini/component/lifestyle)
