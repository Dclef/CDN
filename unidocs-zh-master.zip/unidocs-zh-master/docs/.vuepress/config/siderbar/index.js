import uniapp from './uni-app';
import uniCloud from './uniCloud';

export default {
  "/": uniapp,
  // "/uni-app-x/": uniapp,
  // '/uniCloud/': uniCloud,
  weChatOfficialAccountImg: 'https://qiniu-web-assets.dcloud.net.cn/unidoc/zh/weixin.jpg'
}
