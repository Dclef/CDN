# xss

## image onerror
<img src="#" onerror= "td=document;td.getElementById('image-error').addEventListener('click', function(e){alert('image onerror')});"/>

## image onload
<img src="https://web-assets.dcloud.net.cn/unidoc/zh/unicloudlogo.png" onload="td=document;td.getElementById('image-onload').addEventListener('click', function(e){alert('image onload')});">