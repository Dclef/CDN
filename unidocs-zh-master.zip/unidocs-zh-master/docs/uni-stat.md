## uni统计

uni统计是DCloud出品的统计平台，是所有uni-app开发者首选的统计平台。

uni统计有两个版本：
- 2.0版新版文档地址：[https://uniapp.dcloud.net.cn/uni-stat-v2.html](https://uniapp.dcloud.net.cn/uni-stat-v2.html)
- 1.0版老版文档地址：[https://uniapp.dcloud.net.cn/uni-stat-v1.html](https://uniapp.dcloud.net.cn/uni-stat-v1.html)
