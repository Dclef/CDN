#### UDP 通信

- 微信小程序平台，[规范详情](https://developers.weixin.qq.com/miniprogram/dev/api/network/udp/wx.createUDPSocket.html)
- App平台，需下载插件，[插件市场](https://ext.dcloud.net.cn/search?q=udp)
