export default {
  onThisPage: '本页导读',
  collapseText: '展示全部',
  expandText: '收起目录'
}