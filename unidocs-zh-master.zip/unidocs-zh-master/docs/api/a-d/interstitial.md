### 插屏广告

[插屏广告介绍](https://uniapp.dcloud.net.cn/component/ad-interstitial.html)

**平台差异说明**

|App|H5|微信小程序|支付宝小程序|百度小程序|抖音小程序、飞书小程序|QQ小程序|快手小程序|京东小程序|
|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
|App 3.1.10+|x|√|x|x|x|√|x|x|

**开通配置广告**

[开通广告步骤详情](https://uniapp.dcloud.net.cn/uni-ad.html#start)


文档已迁移至 [插屏视频](https://uniapp.dcloud.net.cn/uni-ad/ad-interstitial.html)
