## 短视频内容联盟组件

### 简介

⼀个视频内容频道，支持上下滑动切换视频内容

![](https://qiniu-web-assets.dcloud.net.cn/unidoc/zh/ad-content-page.png)

**平台差异说明**

|App|H5|微信小程序|支付宝小程序|百度小程序|抖音小程序、飞书小程序|QQ小程序|快应用|360小程序|快手小程序|京东小程序|
|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
|✓|x|x|x|x|x|x|x|x|x|x|

**开通配置广告**

[开通广告步骤详情](https://uniapp.dcloud.net.cn/uni-ad.html#start)


文档已迁移至 [短视频内容联盟广告](https://uniapp.dcloud.net.cn/uni-ad/ad-content-page.html)
