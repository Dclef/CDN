
#### uni.reportAnalytics(string eventName, Object data)

自定义分析数据上报接口。使用前，需要在小程序管理后台自定义分析中新建事件，配置好事件名与字段。。

微信小程序平台[规范详情](https://developers.weixin.qq.com/miniprogram/dev/api/wx.reportAnalytics.html)
QQ小程序平台[规范详情](https://q.qq.com/wiki/develop/game/API/open-port/port_dataanalysis.html#qq-reportanalytics)